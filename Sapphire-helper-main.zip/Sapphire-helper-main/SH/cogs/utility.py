from __future__ import annotations

import discord
from discord.ext import commands
from discord import app_commands, ui
import asyncio
import datetime
import os
from dotenv import load_dotenv
from functions import remove_post_from_rtdr, get_post_creator_id, \
                    generate_random_id, remove_post_from_pending
from aiocache import cached
from typing import Union, Literal, Optional, TYPE_CHECKING
import re
if TYPE_CHECKING:
    from main import MyClient


load_dotenv()

SOLVED_TAG_ID = int(os.getenv("SOLVED_TAG_ID"))
NOT_SOLVED_TAG_ID = int(os.getenv("NOT_SOLVED_TAG_ID"))
SUPPORT_CHANNEL_ID = int(os.getenv('SUPPORT_CHANNEL_ID'))
NEED_DEV_REVIEW_TAG_ID = int(os.getenv('NEED_DEV_REVIEW_TAG_ID'))
CUSTOM_BRANDING_TAG_ID = int(os.getenv('CUSTOM_BRANDING_TAG_ID'))
EXPERTS_ROLE_ID = int(os.getenv("EXPERTS_ROLE_ID"))
MODERATORS_ROLE_ID = int(os.getenv("MODERATORS_ROLE_ID"))
NDR_CHANNEL_ID = int(os.getenv('NDR_CHANNEL_ID'))
ALERTS_THREAD_ID = int(os.getenv('ALERTS_THREAD_ID'))
QR_LOG_THREAD_ID = int(os.getenv("QR_LOG_THREAD_ID"))
APPEAL_GG_TAG_ID = int(os.getenv("APPEAL_GG_TAG_ID"))
WAITING_FOR_REPLY_TAG_ID = int(os.getenv("WAITING_FOR_REPLY_TAG_ID"))
UNANSWERED_TAG_ID = int(os.getenv("UNANSWERED_TAG_ID"))
DEVELOPERS_ROLE_ID = int(os.getenv('DEVELOPERS_ROLE_ID'))

class need_dev_review_buttons(ui.View):
    def __init__(self):
        super().__init__(timeout=None)
    
    @ui.button(label="Show an example of the questions answered", style=discord.ButtonStyle.grey, custom_id="need-dev-review-example")
    async def on_show_example_click(self, interaction: discord.Interaction, button: ui.Button):
        await interaction.response.send_message(
            content="## Example message on how you could answer these questions for an imaginary issue.\n\n1. Join Roles\n2. Last join role assigned yesterday at 6:03 am UTC\
            \n3. Join Roles are not being assigned. Steps:\n  - Added role \"Users\" (701822101941649558) to Join Roles in dashboard.\n  - Worked fine for two months.\n  - Suddenly stopped.\
            \n4. Yes, in one server as well but not in another.\n5. IDs:\n  - 678279978244374528 (my main server)\n  - 181730794815881216 (does not work as well)\n  - 288847386002980875 (works there)\
            \n6. I did:\n  - Removed Join Role and set it again in the dashboard\n7. Yes, we rely on Sapphire's Join Roles very much", 
            ephemeral=True
            )
    @ui.button(label="How to get a server's ID?", style=discord.ButtonStyle.grey, custom_id="how-to-get-server-id")
    async def on_how_to_get_server_id_click(self, interaction: discord.Interaction, button: ui.Button):
        embed = discord.Embed(
            title="How to find your server's ID",
            description="1. Open [Sapphire's dashboard](https://dashboard.sapph.xyz).\n2. Select your server.\n3. Find your server ID (16-19 long number) in the URL."
        )
        embed.set_image(url="https://img-temp.sapph.xyz/fef61749-efb4-46c5-4015-acc7311d7900")
        await interaction.response.send_message(embed=embed, ephemeral=True)

class ndr_options_buttons(ui.View):
    def __init__(self, Interaction: discord.Interaction):
        super().__init__(timeout=None)
        self.Interaction = Interaction
    
    async def mark_post_as_ndr(self, post: discord.Thread):
        ndr = post.parent.get_tag(NEED_DEV_REVIEW_TAG_ID)
        tags = [ndr]
        cb = post.parent.get_tag(CUSTOM_BRANDING_TAG_ID)
        appeal = post.parent.get_tag(APPEAL_GG_TAG_ID)
        if cb in post.applied_tags: 
            tags.append(cb)
        if appeal in post.applied_tags:
            tags.append(appeal)
        action_id = generate_random_id()
        try:
            alerts_thread = post.guild.get_channel_or_thread(ALERTS_THREAD_ID) or await post.guild.fetch_channel(ALERTS_THREAD_ID)
        except discord.NotFound as e:
            raise e
        await post.edit(applied_tags=tags, reason=f"ID: {action_id}. Post marked as needs-dev-review with /needs-dev-review")
        if alerts_thread.archived:
            await alerts_thread.edit(archived=False)
        await alerts_thread.send(content=f"ID: {action_id}\nPost: {post.mention}\nTags: {','.join([tag.name for tag in tags])}\nContext: /needs-dev-review command used")
        channel = post.guild.get_channel(NDR_CHANNEL_ID)
        await channel.send(f'A new post has been marked as "Needs dev review"\n> {post.mention}')
        await remove_post_from_pending(post.id)

    @ui.button(label="Only add tag", style=discord.ButtonStyle.grey, custom_id="ndr-only-add-tag")
    async def on_only_add_tag_click(self, interaction: discord.Interaction, button: ui.Button):
        await interaction.response.defer(ephemeral=False)
        await self.mark_post_as_ndr(interaction.channel)
        await interaction.channel.send(content="Post successfully marked as *needs-dev-review*.")
        await self.Interaction.delete_original_response()

    @ui.button(label="Add tag & send questions", style=discord.ButtonStyle.grey, custom_id="ndr-tag-and-questions")
    async def on_send_questions_click(self, interaction: discord.Interaction, button: ui.Button):
        await interaction.response.defer()
        await self.mark_post_as_ndr(interaction.channel)
        embed = discord.Embed(
                    description=f"# Waiting for dev review\nThis post was marked as **<:sapphire_red:908755238473834536> Needs dev review** by {interaction.user.mention}\n\n### Please answer _all_ of the following questions, regardless of whether they have already been answered somewhere in this post.\n1. Which feature(s) are connected to this issue?\n2. When did this issue start to occur?\n3. What is the issue and which steps lead to it?\n4. Can this issue be reproduced by other users/in other servers?\n5. Which server IDs are related to this issue?\n6. What did you already try to fix this issue by yourself? Did it work?\n7. Does this issue need to be fixed urgently?\n\n_ _",
                    colour=0x2b2d31
                )
        embed.set_footer(text="Thank you for helping Sapphire to continuously improve.")
        await interaction.channel.send(embed=embed, view=need_dev_review_buttons())
        await self.Interaction.delete_original_response()

class utility(commands.Cog):
    def __init__(self, client: MyClient):
        self.client = client
        
    async def send_action_log(self, action_id: str, post_mention: str, tags: list[discord.ForumTag], context: str):
        if self.client.alert_webhook_url is not None:
            webhook = discord.Webhook.from_url(self.client.alert_webhook_url, client=self.client)
            try:
                await webhook.send(
                    content=f"ID: {action_id}\nPost: {post_mention}\nTags: {', '.join([tag.name for tag in tags])}\nContext: {context}",
                    username=self.client.user.name,
                    avatar_url=self.client.user.display_avatar.url,
                    thread=discord.Object(id=ALERTS_THREAD_ID),
                    wait=False
                )
                return
            except Exception:
                pass #pass to try the other methods below
        try:
            alerts_thread = self.client.get_channel(ALERTS_THREAD_ID) or await self.client.fetch_channel(ALERTS_THREAD_ID)
        except discord.NotFound as e:
            raise e
        if alerts_thread.archived:
            await alerts_thread.edit(archived=False)
        webhooks = [webhook for webhook in await alerts_thread.parent.webhooks() if webhook.token]
        try:
            webhook = webhooks[0] 
        except IndexError:
            webhook = await alerts_thread.parent.create_webhook(name="Created by Sapphire Helper", reason="Create a webhook for action logs, EPI logs and so on. It will be reused in the future if it wont be deleted.")
        await webhook.send(
            content=f"ID: {action_id}\nPost: {post_mention}\nTags: {', '.join([tag.name for tag in tags])}\nContext: {context}",
            username=self.client.user.name,
            avatar_url=self.client.user.display_avatar.url,
            thread=discord.Object(id=ALERTS_THREAD_ID),
            wait=False
        )
        self.client.alert_webhook_url = webhook.url #Assign only if the url is None. This should normally only be called once when running the bot

    @cached()
    async def get_unsolve_id(self) -> int:
        """  
        Get the id of /unsolve command.
        This fetches the command from discord and caches the result
        """
        unsolve_id = 1281211280618950708
        for command in await self.client.tree.fetch_commands():
            if command.name == "unsolve": 
                unsolve_id=command.id
                break
            else:
                continue
        return unsolve_id
    
    @cached()
    async def get_solved_id(self):
        solved_id = 1274997472162349079
        for command in await self.client.tree.fetch_commands():
                if command.name == "solved": 
                    solved_id=command.id
                    break
                else:
                    continue
        return solved_id

    close_tasks: dict[int, asyncio.Task] = {} # posts that are waiting to be closed with their respective asyncio.Task

    async def close_post(self, post: discord.Thread, close_delay: float = 3600) -> None:
        """  
        Used with asyncio.create_task to close the given post after the given delay in seconds.
        """
        await asyncio.sleep(close_delay) # wait for close_delay hours
        await post.edit(
            archived=True,
            reason=f"Auto archive {'solved' if close_delay == 3600 else 'unrelated'} post after {close_delay} seconds"
        )
        self.close_tasks.pop(post.id)
        await remove_post_from_rtdr(post.id)
        await remove_post_from_pending(post.id)
        if post.id in self.client.incomplete_msg_posts:
            self.client.incomplete_msg_posts.remove(post.id)

    async def mark_post_as_solved(self, post: discord.Thread) -> None:
        """  
        Mark the given post as solved- adds tags and create task with delay to archive it.
        Returns the task
        """
        solved = post.parent.get_tag(SOLVED_TAG_ID)
        cb = post.parent.get_tag(CUSTOM_BRANDING_TAG_ID)
        appeal = post.parent.get_tag(APPEAL_GG_TAG_ID)
        tags = [solved]
        if cb in post.applied_tags: 
            tags.append(cb)
        if appeal in post.applied_tags:
            tags.append(appeal)
        action_id = generate_random_id()
        await post.edit(applied_tags=tags, reason=f"ID: {action_id}. Post marked as solved with /solved")
        await self.send_action_log(action_id=action_id, post_mention=post.mention, tags=tags, context="/solved used")
        task = asyncio.create_task(self.close_post(post=post))
        self.close_tasks[post.id] = task

    async def lock_unrelated_post(self, post: discord.Thread) -> None:
        """
        Lock the given post, override the tags to the solved tag and create a task with a delay to archive it
        """
        solved = [post.parent.get_tag(SOLVED_TAG_ID)]
        action_id = generate_random_id()
        await post.edit(locked=True, applied_tags=solved, reason=f'ID: {action_id}. Post locked as it was not sapphire related')
        await self.send_action_log(action_id=action_id, post_mention=post.mention, tags=solved, context="/unrelated used")
        asyncio.create_task(self.close_post(post=post, close_delay=600))

    async def unsolve_post(self, post: discord.Thread) -> None:
        """  
        Cancel marking the given post as solved, used in /unsolve command
        """
        if post.id in self.close_tasks: 
            self.close_tasks[post.id].cancel()
            del self.close_tasks[post.id]
        not_solved = post.parent.get_tag(NOT_SOLVED_TAG_ID)
        cb = post.parent.get_tag(CUSTOM_BRANDING_TAG_ID)
        appeal = post.parent.get_tag(APPEAL_GG_TAG_ID)
        tags = [not_solved]
        if cb in post.applied_tags: 
            tags.append(cb)
        if appeal in post.applied_tags:
            tags.append(appeal)
        action_id = generate_random_id()
        await post.edit(applied_tags=tags, reason=f"ID: {action_id}. Post unsolved with /unsolve")
        await self.send_action_log(action_id=action_id, post_mention=post.mention, tags=tags, context="/unsolve used")

    @staticmethod
    async def one_of_mod_expert_op(interaction: discord.Interaction):
        """  
        Checks if the interaction user is a Moderator or Community Expert or the creator of the post\n
        --Integrated with rtdr system
        """
        if isinstance(interaction.channel, discord.Thread) and interaction.channel.parent_id == SUPPORT_CHANNEL_ID:
            owner_id = await get_post_creator_id(interaction.channel_id) or interaction.channel.owner_id
            return bool(interaction.user.get_role(EXPERTS_ROLE_ID) or interaction.user.get_role(MODERATORS_ROLE_ID) or interaction.user.get_role(DEVELOPERS_ROLE_ID)) or interaction.user.id == owner_id
        else:
            return False
        
    @staticmethod
    async def is_mod_or_expert(interaction: discord.Interaction):
        """  
        Checks if the interaction user is a Moderator or Community Expert
        """
        return bool(interaction.user.get_role(EXPERTS_ROLE_ID) or interaction.user.get_role(MODERATORS_ROLE_ID) or interaction.user.get_role(DEVELOPERS_ROLE_ID))

    @commands.Cog.listener()
    async def on_ready(self):
        self.client.add_view(need_dev_review_buttons()) # add the need dev review button/view to make it persistent (work after restart)

    @app_commands.command(name="solved", description="Mark the current post as solved")
    @app_commands.check(one_of_mod_expert_op)
    @app_commands.guild_only()
    async def solved(self, interaction: discord.Interaction):
        if NEED_DEV_REVIEW_TAG_ID not in interaction.channel._applied_tags and "forwarded" not in interaction.channel.name.casefold():
            if SOLVED_TAG_ID not in interaction.channel._applied_tags:
                await self.mark_post_as_solved(interaction.channel)
                one_hour_from_now = datetime.datetime.now() + datetime.timedelta(hours=1)
                try:
                    await interaction.response.send_message(content=f"This post was marked as solved.\n-# It will be automatically closed <t:{round(one_hour_from_now.timestamp())}:R>. Use </unsolve:{await self.get_unsolve_id()}> to cancel.")
                except discord.NotFound:
                    await interaction.channel.send(content=f"This post was marked as solved.\n-# It will be automatically closed <t:{round(one_hour_from_now.timestamp())}:R>. Use </unsolve:{await self.get_unsolve_id()}> to cancel.")
            else:
                await interaction.response.send_message(content="This post is already marked as solved.", ephemeral=True)
        else:
            button = ui.Button(label="Confirm", style=discord.ButtonStyle.green, custom_id="solved-confirm")
            async def on_confirm_button_click(Interaction: discord.Interaction):
                await self.mark_post_as_solved(interaction.channel)
                one_hour_from_now = datetime.datetime.now() + datetime.timedelta(hours=1)
                await Interaction.response.defer(ephemeral=True)
                await Interaction.delete_original_response()
                await Interaction.channel.send(content=f"This post was marked as solved.\n-# It will be automatically closed <t:{round(one_hour_from_now.timestamp())}:R>. Use </unsolve:{await self.get_unsolve_id()}> to cancel.")
            button.callback = on_confirm_button_click
            view = ui.View() # construct an empty view item
            view.add_item(button)
            await interaction.response.send_message(content="This post has the **needs-dev-review tag**, are you sure you would like to mark it as solved?", view=view, ephemeral=True)
            
    @app_commands.command(name="remove", description="Remove the given member from the current post")
    @app_commands.guild_only()
    @app_commands.describe(user="What user do you want to remove?", reason="The reason for removing the user")
    @app_commands.checks.has_any_role(EXPERTS_ROLE_ID, MODERATORS_ROLE_ID, DEVELOPERS_ROLE_ID)
    async def remove(self, interaction: discord.Interaction, user: discord.Member, reason: str = "No reason provided."):
        if isinstance(interaction.channel, discord.Thread) and interaction.channel.parent_id == SUPPORT_CHANNEL_ID:
            is_owner = user.id == interaction.channel.owner_id or user.id == await get_post_creator_id(interaction.channel_id)
            if is_owner:
                await interaction.response.send_message(f"{user.mention} is the owner of this post. Therefore they cannot be removed.", ephemeral=True)
                return
            await interaction.channel.remove_user(user)
            await interaction.response.send_message(content=f"Successfully removed {user.mention} from this post.", ephemeral=True)
            try:
                alerts_thread = self.client.get_channel(ALERTS_THREAD_ID) or await self.client.fetch_channel(ALERTS_THREAD_ID)
            except discord.NotFound as e:
                raise e
            if alerts_thread.archived:
                await alerts_thread.edit(archived=False)
            await alerts_thread.send(f"{interaction.user.mention} removed {user.mention} from {interaction.channel.mention}.\nReason: {reason}", allowed_mentions=discord.AllowedMentions.none())
        else:
            await interaction.response.send_message(content=f"This command is only usable in a post in <#{SUPPORT_CHANNEL_ID}>", ephemeral=True)

    @app_commands.command(name="unsolve", description="Cancel the post from being closed")
    @app_commands.check(one_of_mod_expert_op)
    @app_commands.guild_only()
    async def unsolved(self, interaction: discord.Interaction):
        if interaction.channel in self.close_tasks or SOLVED_TAG_ID in interaction.channel._applied_tags:
            await self.unsolve_post(interaction.channel)
            content = f"Post successfully unsolved!\nPlease send a message here explaining what you still need help with.\n-# If the post is solved you may use </solved:{await self.get_solved_id()}> to mark it as solved."
            if interaction.user.get_role(EXPERTS_ROLE_ID) or interaction.user.get_role(MODERATORS_ROLE_ID) or interaction.user.get_role(DEVELOPERS_ROLE_ID):
                content = "Post successfully unsolved!"
            await interaction.response.send_message(content=content)
        else:
            await interaction.response.send_message(content="This post isn't currently marked as solved...\nTry again later", ephemeral=True)

    @app_commands.command(name="needs-dev-review", description="This post needs to be reviewed by the developer")
    @app_commands.guild_only()
    @app_commands.checks.has_any_role(EXPERTS_ROLE_ID, MODERATORS_ROLE_ID, DEVELOPERS_ROLE_ID)
    async def need_dev_review(self, interaction: discord.Interaction):
        if isinstance(interaction.channel, discord.Thread) and interaction.channel.parent_id == SUPPORT_CHANNEL_ID:
            if NEED_DEV_REVIEW_TAG_ID not in interaction.channel._applied_tags:
                await interaction.response.send_message(ephemeral=True, view=ndr_options_buttons(interaction), content="Select one of the options below or dismiss message to cancel.")
            else:
                await interaction.response.send_message(content="This post already has needs-dev-review tag.", ephemeral=True)
        else:
            await interaction.response.send_message(f"This command is only usable in a post in <#{SUPPORT_CHANNEL_ID}>", ephemeral=True)

    async def send_qr_log(self, message: discord.Message, user: discord.Member):
        try:
            qr_logs_thread = self.client.get_channel(QR_LOG_THREAD_ID) or await self.client.fetch_channel(QR_LOG_THREAD_ID)
        except discord.NotFound as e:
            raise e
        webhooks = [webhook for webhook in await qr_logs_thread.parent.webhooks() if webhook.token]
        try:
            webhook = webhooks[0]
        except IndexError:
            webhook = await qr_logs_thread.parent.create_webhook(name="Created by Sapphire Helper", reason="Create a webhook for action logs, EPI logs and so on. It will be reused in the future if it wont be deleted.")
        if qr_logs_thread.archived:
            await qr_logs_thread.edit(archived=False)
        await webhook.send(
            content=f"Message deleted by {user.mention} in {message.channel.mention}\nMessage id: `{message.id}`",
            username=self.client.user.name,
            avatar_url=self.client.user.display_avatar.url,
            thread=discord.Object(id=QR_LOG_THREAD_ID),
            allowed_mentions=discord.AllowedMentions.none()
        )

    def get_user_id_from_avatar(self, avatar_url: str) -> int | None:
        """Gets the user_id from a users avatar"""

        guild_member_avatar_regex = r"^https?:\/\/cdn\.discord(?:app)?\.com\/guilds\/\d+\/users\/\d+\/avatars\/"
        user_avatar_regex = r"^https?:\/\/cdn\.discord(?:app)?\.com\/avatars\/\d+\/"
        if re.match(user_avatar_regex, avatar_url, re.IGNORECASE):
            user_id = int(avatar_url.split("/")[4]) #https://cdn.discordapp.com/avatars/user_id/user_avatar.png -> ['https:', '', 'cdn.discordapp.com', 'avatars', 'user_id', 'user_avatar.png']
        elif re.match(guild_member_avatar_regex, avatar_url, re.IGNORECASE):
            user_id = int(avatar_url.split("/")[6]) #https://cdn.discordapp.com/guilds/guild_id/users/user_id/avatars/member_avatar.png -> ['https:', '', 'cdn.discordapp.com', 'guilds', 'guild_id', 'users', 'user_id', 'avatars', 'member_avatar.png']
        else:
            user_id = None
        return user_id

    @commands.Cog.listener('on_reaction_add')
    async def delete_accidental_qr(self, reaction: discord.Reaction, user: Union[discord.Member, discord.User]):
        in_support = isinstance(reaction.message.channel, discord.Thread) \
            and reaction.message.channel.parent_id == SUPPORT_CHANNEL_ID
        from_sapphire_or_helper = reaction.message.author.id == 678344927997853742 or \
                                reaction.message.author.id == self.client.user.id
        reaction_allowed = reaction.emoji in ["🗑️", "❌"]
        if in_support and from_sapphire_or_helper and reaction_allowed:
            if user.get_role(EXPERTS_ROLE_ID) or user.get_role(MODERATORS_ROLE_ID) or user.get_role(DEVELOPERS_ROLE_ID):
                await reaction.message.delete()
                await self.send_qr_log(reaction.message, user)
                return
            if reaction.message.interaction_metadata:
                if reaction.message.interaction_metadata.user == user:
                    await reaction.message.delete()
                    await self.send_qr_log(message=reaction.message, user=user)
                    return
            elif reaction.message.embeds:
                if reaction.message.embeds[len(reaction.message.embeds)-1].footer:
                    footer = reaction.message.embeds[len(reaction.message.embeds)-1].footer

                    regex = f'(Recommended|Sent) by @{user.name}'
                    if footer.text and re.match(regex, footer.text, re.IGNORECASE):
                        await reaction.message.delete()
                        await self.send_qr_log(message=reaction.message, user=user)
                        return

                    if footer.icon_url:
                        user_id = self.get_user_id_from_avatar(footer.icon_url)
                        if user_id is not None and user_id == user.id:
                            await reaction.message.delete()
                            await self.send_qr_log(message=reaction.message, user=user)
                            return
            if reaction.message.reference and reaction.message.reference.cached_message:
                if user == reaction.message.reference.cached_message.author:
                    await reaction.message.delete()
                    await self.send_qr_log(reaction.message, user)
                    return
            if reaction.message.content and reaction.message.content.endswith(f"Recommended by {user.mention}"):
                await reaction.message.delete()
                await self.send_qr_log(reaction.message, user)
                return    

    @app_commands.command(name="atbl", description="Mark the current post as 'Added to bug list'")
    @app_commands.describe(priority="The priority of this issue")
    @app_commands.checks.has_any_role(MODERATORS_ROLE_ID, EXPERTS_ROLE_ID, DEVELOPERS_ROLE_ID)
    async def atbl(self, interaction: discord.Interaction, priority: Literal["Very Low", "Low", "Medium", "High", "Special Issue"]):
        if isinstance(interaction.channel, discord.Thread) and interaction.channel.parent_id == SUPPORT_CHANNEL_ID:
            priority_texts = {
                "very low": "We'll get to this eventually.",
                "low": "We'll take care of this when we have time and if there are no higher-priority bugs.",
                "medium": "We'll probably get to this in about 1-2 weeks, unless something more urgent comes up.",
                "high": "We'll fix this as soon as we can.",
                "special issue": "User specific issue"
            }
            embed = discord.Embed(
                title="",
                description="### The development team has added this bug to their tracking list.",
                colour=0xe88802
            )
            embed.add_field(name="Priority", value=priority, inline=False)
            if priority.casefold() != "special issue":
                embed.add_field(name="When is this issue expected to be resolved?", value=priority_texts.get(priority.casefold()), inline=False)
            await interaction.response.send_message(embed=embed)
            ndr = interaction.channel.parent.get_tag(NEED_DEV_REVIEW_TAG_ID)
            cb = interaction.channel.parent.get_tag(CUSTOM_BRANDING_TAG_ID)
            appeal = interaction.channel.parent.get_tag(APPEAL_GG_TAG_ID)
            tags = [ndr]
            if cb in interaction.channel.applied_tags:
                tags.append(cb)
            if appeal in interaction.channel.applied_tags:
                tags.append(appeal)
            await interaction.channel.edit(name=f"[ATBL] {interaction.channel.name}", reason=f"@{interaction.user.name} used /atbl", applied_tags=tags)
        else:
            await interaction.response.send_message(content=f"This command can only be used in <#{SUPPORT_CHANNEL_ID}>!", ephemeral=True)

    @commands.hybrid_command(name="incomplete-post", description="Request more information from the post creator")
    @commands.guild_only()
    async def incomplete_post(self, ctx: commands.Context):
        await ctx.defer(ephemeral=True)
        if isinstance(ctx.channel, discord.Thread) and ctx.channel.parent_id == SUPPORT_CHANNEL_ID:
            if SOLVED_TAG_ID not in ctx.channel._applied_tags and NEED_DEV_REVIEW_TAG_ID not in ctx.channel._applied_tags:
                if ctx.channel.id not in self.client.incomplete_msg_posts:
                    user_id = await get_post_creator_id(ctx.channel.id) or ctx.channel.owner_id
                    content = None
                    if ctx.author.get_role(EXPERTS_ROLE_ID) or ctx.author.get_role(MODERATORS_ROLE_ID) or ctx.author.get_role(DEVELOPERS_ROLE_ID):
                        content = f"<@{user_id}>"
                    embed = discord.Embed(
                        title="Incomplete support post",
                        description="Hey, it seems like your support post is incomplete. Please make sure to provide the following information:\n\n> `-` What feature do you need help with?\n> `-` What exactly is the issue / what are you trying to do?\n> `-` What did you already try?\n> `-` Include screenshots if possible",
                        colour=0xFFA800
                    )
                    embed.set_footer(text=f"Recommended by @{ctx.author.name}", icon_url=ctx.author.display_avatar.url)
                    if not ctx.interaction:
                        await ctx.message.delete()
                    elif ctx.interaction:
                        await ctx.interaction.delete_original_response()
                    if WAITING_FOR_REPLY_TAG_ID in ctx.channel._applied_tags or UNANSWERED_TAG_ID in ctx.channel._applied_tags:
                        tags = [ctx.channel.parent.get_tag(NOT_SOLVED_TAG_ID)]
                        if CUSTOM_BRANDING_TAG_ID in ctx.channel._applied_tags:
                            tags.append(ctx.channel.parent.get_tag(CUSTOM_BRANDING_TAG_ID))
                        if APPEAL_GG_TAG_ID in ctx.channel._applied_tags:
                            tags.append(ctx.channel.parent.get_tag(APPEAL_GG_TAG_ID))
                        action_id = generate_random_id()
                        await ctx.channel.edit(applied_tags=tags, reason=f"ID: {action_id}. @{ctx.author.name} used /incomplete-post")
                        await self.send_action_log(action_id, ctx.channel.mention, tags, "/incomplete-post used")
                    await ctx.channel.send(content=content, embed=embed)
                else:
                    await ctx.reply("You cannot use this command as an automatic message was already sent.", ephemeral=True, delete_after=3)
            else:
                await ctx.reply("You cannot use this command as this post has the *Solved* or *Needs dev review* tag.", ephemeral=True, delete_after=3)
        else:
            await ctx.reply(content=f"This command can only be used in <#{SUPPORT_CHANNEL_ID}>!", ephemeral=True)


    async def non_expert_mod_cooldown(interaction: discord.Interaction):
        """
        Returns a cooldown of 1 use per 5 minutes if the command author is not expert or mod
        """
        if interaction.user.get_role(MODERATORS_ROLE_ID) or interaction.user.get_role(EXPERTS_ROLE_ID) or interaction.user.get_role(DEVELOPERS_ROLE_ID):
            return None
        
        return commands.Cooldown(1,  5.0 * 60.0)

    # def unrelated_cooldown_key(interaction: discord.Interaction):
    #     """
    #     The key used to define the cooldown by
    #     """
    #     return interaction.channel_id
    # this is only here because it may be useful someday idk


    @app_commands.command(
            name='unrelated',
            description='Inform the post creator that their question/issue is not Sapphire/appeal.gg related.'
    )
    @app_commands.guild_only()
    @app_commands.checks.dynamic_cooldown(non_expert_mod_cooldown)
    async def wrong_server(self, interaction: discord.Interaction):
        await interaction.response.defer()

        embed = discord.Embed(
            title="Unrelated question/issue",
            description="Hey, your question/issue **is not related** to Sapphire or appeal.gg. Please search for the proper server/resource to get an answer to your question.\nWe cannot help you any further with your query.",
            colour=discord.Colour.purple()
        )
        embed.set_footer(text=f"Recommended by @{interaction.user.name}", icon_url=interaction.user.display_avatar.url)

        content = ""
        if isinstance(interaction.channel, discord.Thread) and await self.is_mod_or_expert(interaction=interaction):
            if interaction.channel.parent_id == SUPPORT_CHANNEL_ID:
                user_id = await get_post_creator_id(interaction.channel_id) or interaction.channel.owner_id
                content = f"<@{user_id}>"
                await self.lock_unrelated_post(interaction.channel)

        await interaction.channel.send(content=content, embed=embed)
        await interaction.delete_original_response()

async def setup(client: MyClient):
    await client.add_cog(utility(client))

